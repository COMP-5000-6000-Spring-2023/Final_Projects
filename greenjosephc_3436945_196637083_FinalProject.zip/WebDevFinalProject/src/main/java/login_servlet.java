import Services.MySQLdb;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "login_servlet", value = "/login_servlet")
public class login_servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String login_username = request.getParameter("login_username");
        String login_password = request.getParameter("login_password");

        MySQLdb mySQLdb = MySQLdb.getInstance();

        String userID = null;
        try{
            userID= mySQLdb.dbLogin(login_username, login_password);
        }catch (SQLException e){
            e.printStackTrace();
        }


        if(userID != null){
            HttpSession session = request.getSession();
            session.setAttribute("user", userID);

            RequestDispatcher requestDispatcher = request.getRequestDispatcher("home.jsp");
            requestDispatcher.forward(request, response);
        }
        else{
            request.setAttribute("error", "Incorrect Username or Password");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("login.jsp");
            requestDispatcher.forward(request, response);
        }
    }
}
